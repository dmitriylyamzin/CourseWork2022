﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SC.Controllers
{
    class Anemia
    {
        public int countOfPoins = 67;
        public string title = "Анемия";

        public string headache = "+???";
        public string highPressure = "-?";
        public string lowPressure = "-";
        public string earNoise = "+";
        public string vertigo = "+";
        public string eyeVisions = "-";
        public string nosebleeds = "-";
        public string suddenAttack = "-";
        public string afterActivityAttack = "-";
        public string chestOrHeartPain = "--???";
        public string chestOrHeartPressure = "--";
        public string heartPainIrradiation = "-?????";
        public string heartPace = "+-?";
        public string sweat = "-?";
        public string hardBreath = "+?????";
        public string fear = "-";
        public string weakness = "+";
        public string nausea = "-";
        public string vomiting = "-";
        public string lungsEdema = "-";
        public string lungsSputum = "-";
        public string cough = "-???";
        public string legsEdema = "-";
        public string constipation = "-";
        public string appetite = "-";
        public string cyanosis = "-";
        public string weightGain = "-";
        public string freqUrination = "-?";
        public string wheezing = "-";
        public string neckVeinIncrease = "-";
        public string skinYellowness = "-";
        public string liverIncrease = "-";
        public string endemas = "-";
        public string hypochondriumPain = "-??";
        public string temperature = "-";
        public string fainting = "-";
        public string whiteSkin = "+";
        public string drySkin = "-";
        public string wetSkin = "-";
        public string cold = "+";
        public string stomachache = "-";
        public string orientationLoss = "-";
        public string movementViolation = "-?";
        public string feelingViolation = "-?";
        public string speechViolation = "-";
        public string sightViolation = "-?";
        public string coordinationViolation = "-";
        public string mouthDryness = "-";
        public string heat = "-";
        public string epilepsy = "-";
        public string jointPain = "-";
        public string skinColorChange = "-";
        public string fingerCyanosis = "-";
        public string redFingers = "-";
        public string loseFingersFeeling = "-";
        public string fingerUlcers = "-";
        public string legsPain = "-?";
        public string legsSeverity = "-";
        public string legsTremorr = "-";
        public string skinItching = "-";
        public string legsDarking = "-";
        public string nailsFragile = "+";
        public string hairLoss = "+";
        public string thirst = "+";
        public string symptomsString = "";

        public void makeSuperstring()
        {
            symptomsString = thirst + hairLoss + nailsFragile + legsDarking + skinItching + legsTremorr + legsSeverity + legsPain + fingerUlcers + loseFingersFeeling + redFingers + fingerCyanosis + skinColorChange + jointPain + epilepsy + heat + mouthDryness + coordinationViolation + sightViolation + speechViolation + feelingViolation + movementViolation + orientationLoss + stomachache + cold + wetSkin + drySkin + whiteSkin + fainting + temperature + hypochondriumPain + endemas + liverIncrease + skinYellowness + neckVeinIncrease + wheezing + freqUrination + weightGain + cyanosis + appetite + constipation + legsEdema + cough + lungsSputum + lungsEdema + vomiting + nausea + weakness + fear + hardBreath + sweat + heartPace + heartPainIrradiation + chestOrHeartPressure + chestOrHeartPain + afterActivityAttack + suddenAttack + nosebleeds + eyeVisions + vertigo + earNoise + lowPressure + highPressure + headache;
        }
    }
}
